# Protector — Pen-and-Paper Intake Demo (Quickstart)

## Mac (Terminal)
```bash
cd ~/Desktop/protector_pen_paper_demo
python3 -m pip install -r requirements.txt
python3 synth_data.py --spec spec.pen_and_paper.clean.yml
python3 make_bad_pen_paper.py clean_base.csv raw_pen_paper_intake.csv
python3 normalize_pen_paper.py raw_pen_paper_intake.csv mapping_config.yml normalized_out/

